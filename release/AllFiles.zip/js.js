function tap(i, i1){
    js.tap(i, i1);
    //document.getElementsByTagName("body")[0].innerHTML = "lol";
}
function setToolBarText(i){
js.setToolBarText(i);
}
